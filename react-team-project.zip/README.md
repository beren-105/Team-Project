파일 변경사항
- 차트
1. App에 있는 내용들을 Rechart파일로 분류
2. 데이터 props로 받게 변경

- 홈
1. 파일 구조 변경으로 인한 import 위치변경
2. 홈 컴포넌트에서 데이터 불러오기 삭제, props로 변경
3. 리스트 컴포넌트에서 데이터를 받아오기 위한 클릭 이벤트 추가

설치해야하는 모듈
차트 : npm install recharts
카카오맵 : npm install react-kakao-maps-sdk
라우터 : npm install react-router-dom


!!!!! .env 파일은 인증키 파일이니 공개된 장소(깃허브)등에 올리지 말아주세요 !!!!!!
(개인정보 보호차원)